package ro.usv.rf;

public class MainClass {
	
	
	public static void main(String[] args) {
		double[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
			//de aici va fi contributia mea
//			for(int patternNr = 1; patternNr < numberOfPatterns; patternNr++)
//			{
//				//System.out.println("Distanta Euclidiana intre linia 1 si "+patternNr+" este: "+DistanceUtils.calculateEuclidianDistance(learningSet[0],learningSet[patternNr]));
//				//System.out.println("Distanta Cebisev intre linia 1 si "+patternNr+" este: "+DistanceUtils.calculateCebisevDistance(learningSet[0], learningSet[patternNr]));
//				//System.out.println("Distanta City Block  intre linia 1 si "+patternNr+" este: "+DistanceUtils.calculateCityBlockDistance(learningSet[0], learningSet[patternNr]));
//				//System.out.println("Distanta Mahalanobis intre linia 1 si "+patternNr+" este: "+DistanceUtils.calculateMahalanobisDistance(learningSet[0], learningSet[patternNr],numberOfPatterns));
//				DistancesController distances=new DistancesController(); 
//				distances=DistanceUtils.calculateAllDistances(learningSet[0], learningSet[patternNr],numberOfPatterns);
//				System.out.println("Distanta Euclidiana intre linia 1 si "+patternNr+" este: "+distances.getEuclidianDistance());
//				System.out.println("Distanta Cebisev intre linia 1 si "+patternNr+" este: "+distances.getCebisevDistance());
//				System.out.println("Distanta City Block  intre linia 1 si "+patternNr+" este: "+distances.getCityblockDistance());
//				System.out.println("Distanta Mahalanobis intre linia 1 si "+patternNr+" este: "+distances.getMahalanobisDistance());
//			}
			
			//De aici va fi pentru laboratorul 4
			double[][] distanceMatrix = new double[learningSet.length][learningSet.length];
			for(int patternNr = 0; patternNr < learningSet.length; patternNr++)
			{
				for(int patternNr2 = patternNr+1; patternNr2 < learningSet.length; patternNr2++)
				{
					DistancesController distances=new DistancesController(); 
					distances=DistanceUtils.calculateAllDistances(learningSet[patternNr], learningSet[patternNr2],numberOfPatterns);
					distanceMatrix[patternNr][patternNr2]=Math.round(distances.getEuclidianDistance()* 100.0) / 100.0;
					distanceMatrix[patternNr2][patternNr] = distanceMatrix[patternNr][patternNr2];
				}
			}
			
			//afisare matrice
			for(int patternNr = 0; patternNr < numberOfPatterns; patternNr++)
			{
				for(int patternNr2 = 0; patternNr2 < numberOfPatterns; patternNr2++)
				{
					System.out.print(distanceMatrix[patternNr][patternNr2]+ " ");
				}
				System.out.println();
			}
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}
