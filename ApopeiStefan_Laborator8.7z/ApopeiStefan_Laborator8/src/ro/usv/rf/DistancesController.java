package ro.usv.rf;

public class DistancesController {

	public double getEuclidianDistance() {
		return euclidianDistance;
	}
	public void setEuclidianDistance(double euclidianDistance) {
		this.euclidianDistance = euclidianDistance;
	}
	public double getCebisevDistance() {
		return CebisevDistance;
	}
	public void setCebisevDistance(double cebisevDistance) {
		CebisevDistance = cebisevDistance;
	}
	public double getCityblockDistance() {
		return cityblockDistance;
	}
	public void setCityblockDistance(double cityblockDistance) {
		this.cityblockDistance = cityblockDistance;
	}
	public double getMahalanobisDistance() {
		return mahalanobisDistance;
	}
	public void setMahalanobisDistance(double mahalanobisDistance) {
		this.mahalanobisDistance = mahalanobisDistance;
	}
	private double euclidianDistance;
	private double CebisevDistance;
	private double cityblockDistance;
	private double mahalanobisDistance;
	

	
}
