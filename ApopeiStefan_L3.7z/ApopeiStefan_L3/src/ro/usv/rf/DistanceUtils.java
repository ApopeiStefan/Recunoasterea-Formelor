package ro.usv.rf;

public class DistanceUtils {
	
	protected static double calculateEuclidianDistance(double [] firstPatern, double [] secondPatern)
	{
		double newDistance=0;
		for(int paternContor=0;paternContor<2;paternContor++)
		{
			newDistance += Math.pow(firstPatern[paternContor] - secondPatern[paternContor], 2);
		}
		return Math.sqrt(newDistance);
	}
	protected static double calculateCebisevDistance(double [] firstPatern, double [] secondPatern)
	{
		double distance=0.0;
		for(int paternContor=0;paternContor<firstPatern.length;paternContor++)
		{
			double newDistance = Math.abs(firstPatern[paternContor] - secondPatern[paternContor]);
			if (newDistance > distance) {
				distance = newDistance;
			}
		}
		return distance;
	}
	
	protected static double calculateCityBlockDistance(double [] firstPatern, double [] secondPatern)
	{
		double newDistance=0.0;
		for(int paternContor=0;paternContor<firstPatern.length;paternContor++)
		{
			newDistance += Math.abs(firstPatern[paternContor] - secondPatern[paternContor]);
		}
		return newDistance;
	}
	protected static double calculateMahalanobisDistance(double [] firstPatern, double [] secondPatern, int numberOfPatterns)
	{
		double newDistance=0.0;
		for(int paternContor=0;paternContor<firstPatern.length;paternContor++)
		{
			newDistance += Math.pow(firstPatern[paternContor] - secondPatern[paternContor],numberOfPatterns);
		}
		return Math.pow(newDistance,1/numberOfPatterns);
	}
	
	protected static DistancesController calculateAllDistances(double [] firstPatern, double [] secondPatern, int numberOfPatterns)
	{
	    DistancesController distances=new DistancesController(); 
	    distances.setEuclidianDistance(calculateEuclidianDistance(firstPatern,secondPatern));
	    distances.setCebisevDistance(calculateCebisevDistance(firstPatern,secondPatern));
	    distances.setCityblockDistance(calculateCityBlockDistance(firstPatern,secondPatern));
	    distances.setMahalanobisDistance(calculateMahalanobisDistance(firstPatern,secondPatern,numberOfPatterns));
		return distances;
	}

}
