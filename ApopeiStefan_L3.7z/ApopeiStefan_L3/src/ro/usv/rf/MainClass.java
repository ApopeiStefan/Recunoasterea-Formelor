package ro.usv.rf;

public class MainClass {
	
	
	public static void main(String[] args) {
		double[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("D:\\Student\\ApopeiStefan_L3\\in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
			//de aici va fi contributia mea
			for(int patternNr = 1; patternNr < numberOfPatterns; patternNr++)
			{
				//System.out.println("Distanta Euclidiana intre linia 1 si "+patternNr+" este: "+DistanceUtils.calculateEuclidianDistance(learningSet[0],learningSet[patternNr]));
				//System.out.println("Distanta Cebisev intre linia 1 si "+patternNr+" este: "+DistanceUtils.calculateCebisevDistance(learningSet[0], learningSet[patternNr]));
				//System.out.println("Distanta City Block  intre linia 1 si "+patternNr+" este: "+DistanceUtils.calculateCityBlockDistance(learningSet[0], learningSet[patternNr]));
				//System.out.println("Distanta Mahalanobis intre linia 1 si "+patternNr+" este: "+DistanceUtils.calculateMahalanobisDistance(learningSet[0], learningSet[patternNr],numberOfPatterns));
				DistancesController distances=new DistancesController(); 
				distances=DistanceUtils.calculateAllDistances(learningSet[0], learningSet[patternNr],numberOfPatterns);
				System.out.println("Distanta Euclidiana intre linia 1 si "+patternNr+" este: "+distances.getEuclidianDistance());
				System.out.println("Distanta Cebisev intre linia 1 si "+patternNr+" este: "+distances.getCebisevDistance());
				System.out.println("Distanta City Block  intre linia 1 si "+patternNr+" este: "+distances.getCityblockDistance());
				System.out.println("Distanta Mahalanobis intre linia 1 si "+patternNr+" este: "+distances.getMahalanobisDistance());

			}
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}
