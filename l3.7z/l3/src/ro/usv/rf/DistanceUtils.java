package ro.usv.rf;

public class DistanceUtils {

	protected static double calculateSimpleEuclidianDistance(double[] pattern1, double pattern2[]) {
		double distance = 0.0;
		for (int feature = 0; feature < 2; feature++) {
			distance += Math.pow(pattern1[feature] - pattern2[feature], 2);
		}

		return Math.sqrt(distance);

	}

	protected static double calculateCebisevDistance(double[] pattern1, double pattern2[]) {
		double distance = 0.0;
		for (int feature = 0; feature < pattern1.length; feature++) {
			double currentValue = Math.abs(pattern1[feature] - pattern2[feature]);
			if (currentValue > distance) {
				distance = currentValue;
			}
		}

		return distance;

	}
	protected static double calculateMahalanobisDistance(double[] pattern1, double pattern2[], int nrOfPatterns) {
		double distance = 0.0;
		for(int feature =0; feature < pattern1.length;feature++) {
			double currentValue = Math.pow(pattern1[feature] - pattern2[feature], nrOfPatterns);
				distance += currentValue;
			
		}
		return Math.pow(distance, (double)1/nrOfPatterns);
	}
	protected static double calculateCityBlock(double[] pattern1, double pattern2[]) {
		double distance = 0.0;
		for (int feature = 0; feature < pattern1.length; feature++) {
			double currentValue = Math.abs(pattern1[feature] - pattern2[feature]);
				distance += currentValue;	
		}

		return distance;

	}
}
