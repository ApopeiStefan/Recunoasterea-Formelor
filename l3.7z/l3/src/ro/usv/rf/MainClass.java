package ro.usv.rf;

public class MainClass {

	public static void main(String[] args) {
		double[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("D:\\3143a\\LAB3RF\\l3\\in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns,
					numberOfFeatures));
			for (int patternNr = 1; patternNr < numberOfPatterns; patternNr++) {
				double euclidianDistance = DistanceUtils.calculateSimpleEuclidianDistance(learningSet[0],
						learningSet[patternNr]);
				System.out.println("The euclidian distance between first pattern and pattern" + patternNr + " is "
						+ euclidianDistance);

				double cebisevDistance = DistanceUtils.calculateCebisevDistance(learningSet[0], learningSet[patternNr]);
				System.out.println("The cebisev distance between first pattern and pattern" + patternNr + " is "
						+ cebisevDistance);

				double mahalanobisDistance = DistanceUtils.calculateMahalanobisDistance(learningSet[0], learningSet[patternNr],numberOfPatterns);
				System.out.println("The mahalanobis distance between first pattern and pattern" + patternNr + " is "
						+ mahalanobisDistance);

				double cityBlock = DistanceUtils.calculateCityBlock(learningSet[0], learningSet[patternNr]);
				System.out.println("The city block distance between first pattern and pattern" + patternNr + " is "
						+ cityBlock);
			}

		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}
