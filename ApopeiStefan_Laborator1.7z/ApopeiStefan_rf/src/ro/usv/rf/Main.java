package ro.usv.rf;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			double[][] learningSet = FileUtils
					.readLearningSetFromFile("C:\\Users\\Stefan\\Desktop\\RF\\ApopeiStefan_rf\\in.txt");
			FileUtils.writeLearningSetToFile("out.csv", normalizeLearningSet(learningSet));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static double[][] normalizeLearningSet(double[][] learningSet) {
		double[][] normalizedLearningSet = new double[learningSet.length][learningSet[0].length];
		// .. enter your code here
		// xij = (xij-xjmin)/(xjmax-xjmin)
		for (int countLine = 0; countLine < learningSet.length; countLine++) {
			for (int countColumn = 0; countColumn < learningSet[0].length; countColumn++) {
				normalizedLearningSet[countLine][countColumn] = round(
						(learningSet[countLine][countColumn] - OnReturnMinFromColumn(learningSet, countColumn))
								/ (OnReturnMaxFromColumn(learningSet, countColumn)
										- OnReturnMinFromColumn(learningSet, countColumn)),
						2);
			}
		}

		for (int i = 0; i < normalizedLearningSet.length; i++) {
			for (int j = 0; j < normalizedLearningSet[i].length; j++) {
				System.out.print(normalizedLearningSet[i][j] + " ");
			}
			System.out.println();
		}
		return normalizedLearningSet;
	}

	private static double OnReturnMaxFromColumn(double[][] learningSet, int columnIndex) {
		double max = Integer.MIN_VALUE;
		for (int i = 0; i < learningSet.length; i++) {

			if (learningSet[i][columnIndex] > max)
				max = learningSet[i][columnIndex];
		}
		// System.out.println("Maximul este: " + max);
		return max;

	}

	private static double OnReturnMinFromColumn(double[][] learningSet, int columnIndex) {
		double min = Integer.MAX_VALUE;
		for (int i = 0; i < learningSet.length; i++) {
			if (learningSet[i][columnIndex] < min)
				min = learningSet[i][columnIndex];
		}
		// System.out.println("Minimul este: " + min);
		return min;
	}

	public static double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		long factor = (long) Math.pow(10, places);
		value = value * factor;
		long tmp = Math.round(value);
		return (double) tmp / factor;
	}
}
